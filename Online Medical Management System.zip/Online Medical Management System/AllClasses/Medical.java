package AllClasses;
import FileSystam.*;
import java.lang.*;
import java.util.*;
import java.io.*;
import Interface.*;
public class Medical implements docop
{
	public void arr(){
		String[] docc={"Tazrian","Faruk"};
		System.out.println("doctor : "+docc[0]);
		System.out.println("doctor : "+docc[1]);
	} 

	public void add()
	{
		System.out.println("A Doctor added");
	}
	public void remove()
	{
		System.out.println("A Doctor removed");
	}

}