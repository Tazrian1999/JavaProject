package AllClasses;
//This Doctor(Child class of a Info) class.
import FileSystam.*;
import Interface.*;
public class Doctor  extends Info{ // Dortor inherits info
	public int yearOfExperience;
	public float fee;
	public String deg;
	static String Numberofdoctor; //static var
	public Salary salary; 
                           
	static
	{
	 	Numberofdoctor="2"; //static run
	}
	public static void Numberofdoctor()
	{
		System.out.println("Number of doctor: "+Numberofdoctor); 
	}	 
	
	public Doctor()
	{
		
	}
	public Doctor(String FirstName,String LastName,String id,String pnum,String pass,String email,int age,String bloodGroup,int yearOfExperience,float fee,String deg,Salary salary)
	{
		super(FirstName, LastName, id, pnum,pass, email, age, bloodGroup);
		this.yearOfExperience=yearOfExperience;
		this.fee=fee;
		this.deg=deg;
		this.salary=salary; 
	}
	public void setsal(Salary salary)
	{
		this.salary=salary;
	}
	Salary getsal()
	{
		return this.salary;
	}
	public void setfee(float fee)
	{
		this.fee=fee;
	}
	float getfee()
	{
		return	this.fee;
	}
	public void setdeg(String deg)
	{
		this.deg=deg;
	}
	String getdeg()
	{
		return	this.deg;
	}
	
	public void show()
	{
		super.show();
		System.out.println("year Of Experience: "+this.yearOfExperience);
		System.out.println("Fee per patient : "+ getfee());
		System.out.println("Degree  : "+ getdeg());	
		System.out.println("Salary: "+salary.getbasicAmount()+ " Festival Bonus is 1/3 of basic Amount: "+salary.getfestivalBonus() + " Over Time  Amount is: "+salary.getovertimeAmount());
		System.out.println("Totall Salary: "+salary.getsal());

	}
}